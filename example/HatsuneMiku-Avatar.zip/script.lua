require("KattMeshDeformation")("HatsuneMiku")
--require("KattMeshDeformation")("ree")
vanilla_model.PLAYER:setVisible(false)
--animations.HatsuneMiku.walk:play()
function events.render()
  models.HatsuneMiku.Root.Spine1.Spine2.ShoulderR.ArmR:setRot(vanilla_model.RIGHT_ARM:getOriginRot()*0.7)
  models.HatsuneMiku.Root.Spine1.Spine2.ShoulderR.ArmR.ForeArmR:setRot(vanilla_model.RIGHT_ARM:getOriginRot()*0.7)
  models.HatsuneMiku.Root.Spine1.Spine2.ShoulderL.ArmL:setRot(vanilla_model.LEFT_ARM:getOriginRot()*0.7)
  models.HatsuneMiku.Root.Spine1.Spine2.ShoulderL.ArmL.ForeArmL:setRot(vanilla_model.LEFT_ARM:getOriginRot()*0.7)
  models.HatsuneMiku.Root.Spine1:setRot(vanilla_model.BODY:getOriginRot())
  models.HatsuneMiku.Root.Spine1.Spine2.Spine3.Head:setRot(vanilla_model.HEAD:getOriginRot()-vanilla_model.BODY:getOriginRot())
  models.HatsuneMiku.Root.ThighR:setRot(vanilla_model.RIGHT_LEG:getOriginRot()*0.7)
  models.HatsuneMiku.Root.ThighR.CalfR:setRot(vanilla_model.RIGHT_LEG:getOriginRot()*0.7)
  models.HatsuneMiku.Root.ThighL:setRot(vanilla_model.LEFT_LEG:getOriginRot()*0.7)
  models.HatsuneMiku.Root.ThighL.CalfL:setRot(vanilla_model.LEFT_LEG:getOriginRot()*0.7)
end

local k = keybinds:newKeybind("Default Dance", "key.keyboard.k")
function pings.defaultDance()
    animations.HatsuneMiku.perryDefaultDance:play()
end
k.press=pings.defaultDance
